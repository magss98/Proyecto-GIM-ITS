
package com.mycompany.gymits.logica;


public class ProfesorMenor extends ActividadMenor {

    public ProfesorMenor(String categoria) {
        super(categoria);
    }

  



  
    
   
    
    
}
