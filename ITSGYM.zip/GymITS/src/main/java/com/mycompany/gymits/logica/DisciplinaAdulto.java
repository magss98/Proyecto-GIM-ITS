
package com.mycompany.gymits.logica;

public class DisciplinaAdulto {
    
    private String zumba = "Zumba";
    private String aerobix = "Aerobic";
    private String funcional = "Funcional";
    private String kickboxing = "Kickboxing";
    private String natacion = "Natacion";

    public DisciplinaAdulto() {
    }

    public String getZumba() {
        return zumba;
    }

    public void setZumba(String zumba) {
        this.zumba = zumba;
    }

    public String getAerobix() {
        return aerobix;
    }

    public void setAerobix(String aerobix) {
        this.aerobix = aerobix;
    }

    public String getFuncional() {
        return funcional;
    }

    public void setFuncional(String funcional) {
        this.funcional = funcional;
    }

    public String getKickboxing() {
        return kickboxing;
    }

    public void setKickboxing(String kickboxing) {
        this.kickboxing = kickboxing;
    }

    public String getNatacion() {
        return natacion;
    }

    public void setNatacion(String natacion) {
        this.natacion = natacion;
    }
    
    
    
    
    
    
    
}
